# Dr Sushant Padha Kundali Analysis — server-protected version

Your calculation formulas (Vargas, Vimshottari dasha, Ashtakavarga, yogas, house
analysis, matching tables) now run on Cloudflare's servers, inside the
`functions/` folder. Only birth details go out from the browser and only the
finished results come back — the formulas themselves are never sent to a
visitor, so there is nothing to copy from "View Source" or dev tools.

## Folder structure (don't rename these — Cloudflare Pages looks for them)
```
public/index.html              ← the website itself (upload this folder's contents as your site)
functions/api/chart.js         ← full kundali calculation (server-side)
functions/api/transit.js       ← transit/gochara calculation (server-side)
functions/api/match.js         ← Ashta-Kuta matching calculation (server-side)
functions/api/_middleware.js   ← basic per-IP rate limit
functions/_lib/engine.js       ← the actual astrology engine (never shipped to browsers)
package.json                   ← lists the one dependency (astronomy-engine)
```

## One-time setup on your computer
You'll need Node.js installed once (from nodejs.org — the "LTS" version). Then,
in a terminal, inside this project folder:

```
npm install -g wrangler
wrangler login
```

`wrangler login` opens your browser — log in with the Cloudflare account you
already have and approve access.

## Deploy (and redeploy any time you update the code)
```
npm install
wrangler pages deploy public --project-name dr-sushant-padha-kundali
```

The first time, Wrangler will ask you to confirm creating a new Pages project
— accept the defaults. It will print a URL like
`https://dr-sushant-padha-kundali.pages.dev` — that's your live site.
The `functions/` folder is picked up automatically; you don't upload it
separately.

## Recommended: add a real rate-limit rule (5 minutes, in the dashboard)
The `_middleware.js` file gives basic protection, but for something reliable:
1. Cloudflare dashboard → your site → **Security → WAF → Rate limiting rules**
2. Create a rule: if URL path starts with `/api/`, allow e.g. 20 requests per
   minute per IP, then block/challenge.
This is available on the free plan for a small number of rules.

## Custom domain (optional)
Cloudflare dashboard → your Pages project → **Custom domains** → add your
domain and follow the DNS instructions shown.

## What changed vs. the static version
- The browser no longer contains the Varga formulas, dasha logic, Ashtakavarga
  tables, yoga rules, or matching tables — those live only in `functions/_lib/engine.js`
  on the server.
- Birth details you enter are sent to your own Cloudflare Worker to be
  calculated, then discarded — nothing is stored or logged by this code.
- The AI Guru tab is unchanged: each visitor still uses their own Anthropic
  API key, sent directly from their browser to Anthropic.

## Honest limits, so you know exactly what this does and doesn't do
- This stops **casual copying** (someone can no longer just view-source your
  formulas). It does **not** stop someone from legally noticing your site's
  layout, feature list, or wording and rebuilding their own version — that's
  true of every website and isn't something code can prevent.
- The astrological rules themselves (Varga formulas, yoga definitions, house
  significations) come from centuries-old, public-domain classical texts
  (Brihat Parashara Hora Shastra, Phaladeepika). Hiding your code protects
  *your specific implementation*, not the underlying classical knowledge,
  which is not anyone's private property to begin with.
- A very determined party could still try to reverse-engineer your formulas by
  sending many test birth times and comparing outputs. The rate-limit rule
  above makes this slow and impractical, not impossible.
