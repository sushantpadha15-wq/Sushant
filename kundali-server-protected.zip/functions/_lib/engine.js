import * as Astronomy from 'astronomy-engine';
/* ===== Dr Sushant Padha Kundali Analysis — calculation core =====
   Astronomy: Astronomy Engine (MIT, ~1 arcminute) loaded in the browser.
   Everything else (ayanamsa, lagna, vargas, dasha, ashtakavarga, yogas, matching) is implemented here. */
const SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const SIGN_SA=['Mesha','Vrishabha','Mithuna','Karka','Simha','Kanya','Tula','Vrischika','Dhanu','Makara','Kumbha','Meena'];
const SIGN_LORD=['Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
const GRAHAS=['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
const SEVEN=['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
const ABBR={Sun:'Su',Moon:'Mo',Mars:'Ma',Mercury:'Me',Jupiter:'Ju',Venus:'Ve',Saturn:'Sa',Rahu:'Ra',Ketu:'Ke',Lagna:'As'};
const NAK=['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','Purva Phalguni','Uttara Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Moola','Purva Ashadha','Uttara Ashadha','Shravana','Dhanishta','Shatabhisha','Purva Bhadrapada','Uttara Bhadrapada','Revati'];
const DASHA_SEQ=['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
const DASHA_YRS={Ketu:7,Venus:20,Sun:6,Moon:10,Mars:7,Rahu:18,Jupiter:16,Saturn:19,Mercury:17};
const AYAN2000=23.85707; // Lahiri (Chitrapaksha) at J2000.0, matches the Swiss Ephemeris definition to <0.1'
const YEAR_DAYS=365.25;
const norm=x=>((x%360)+360)%360;
const rad=d=>d*Math.PI/180, deg=r=>r*180/Math.PI;
const sdiff=(a,b)=>{let d=norm(a-b);return d>180?d-360:d};

/* ---------- time / zone ---------- */
function offsetAt(tz,ms){
  const f=new Intl.DateTimeFormat('en-US',{timeZone:tz,hourCycle:'h23',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric'});
  const p=Object.fromEntries(f.formatToParts(new Date(ms)).map(x=>[x.type,x.value]));
  const asUTC=Date.UTC(+p.year,+p.month-1,+p.day,+p.hour,+p.minute,+p.second);
  return Math.round((asUTC-Math.floor(ms/1000)*1000)/60000);
}
function tzOffsetMin(tz,y,mo,d,h,mi){
  const local=Date.UTC(y,mo-1,d,h,mi);let g=local;
  for(let i=0;i<3;i++)g=local-offsetAt(tz,g)*60000;
  return offsetAt(tz,g);
}
const jdOf=ms=>ms/86400000+2440587.5;
function ayanamsa(ms){const T=(jdOf(ms)-2451545)/36525;return AYAN2000+(5028.796195*T+1.1054348*T*T)/3600}

/* ---------- astronomy ---------- */
const EPS0=23.43927944;
function eclLonJ2000(name,ms){
  const v=Astronomy.GeoVector(name,new Date(ms),true);
  const c=Math.cos(rad(EPS0)),s=Math.sin(rad(EPS0));
  return norm(deg(Math.atan2(v.y*c+v.z*s,v.x)));
}
function meanNode(ms){const T=(jdOf(ms)-2451545)/36525;return norm(125.0445479-1934.1362891*T+0.0020754*T*T)}
function trueNode(ms){
  const T=(jdOf(ms)-2451545)/36525;
  const D=rad(297.8501921+445267.1114034*T),M=rad(357.5291092+35999.0502909*T),Mp=rad(134.9633964+477198.8675055*T),F=rad(93.2720950+483202.0175233*T);
  return norm(meanNode(ms)-1.4979*Math.sin(2*(D-F))-0.15*Math.sin(M)-0.1226*Math.sin(2*D)+0.1176*Math.sin(2*F)-0.0801*Math.sin(2*(Mp-F)));
}
function ascendantTropical(ms,lat,lon){
  const jd=jdOf(ms),T=(jd-2451545)/36525;
  const gmst=280.46061837+360.98564736629*(jd-2451545)+0.000387933*T*T-T*T*T/38710000;
  const ramc=rad(norm(gmst+lon));
  const eps=rad(23.4392911-0.0130042*T);
  return norm(deg(Math.atan2(Math.cos(ramc),-(Math.sin(ramc)*Math.cos(eps)+Math.tan(rad(lat))*Math.sin(eps)))));
}
function siderealPositions(ms,nodeMode){
  const out={},ay=ayanamsa(ms);
  for(const n of SEVEN){
    const f=t=>norm(eclLonJ2000(n,t)-AYAN2000);
    const lon=f(ms),speed=sdiff(f(ms+43200000),f(ms-43200000)); // deg/day
    out[n]={lon,speed,retro:n!=='Sun'&&n!=='Moon'&&speed<0};
  }
  const nf=t=>norm((nodeMode==='true'?trueNode(t):meanNode(t))-ayanamsa(t));
  const r=nf(ms),rs=sdiff(nf(ms+43200000),nf(ms-43200000));
  out.Rahu={lon:r,speed:rs,retro:true};out.Ketu={lon:norm(r+180),speed:rs,retro:true};
  return {pos:out,ayan:ay};
}

/* ---------- dignity ---------- */
const EXALT={Sun:[0,10],Moon:[1,3],Mars:[9,28],Mercury:[5,15],Jupiter:[3,5],Venus:[11,27],Saturn:[6,20]};
const OWN={Sun:[4],Moon:[3],Mars:[0,7],Mercury:[2,5],Jupiter:[8,11],Venus:[1,6],Saturn:[9,10]};
const MOOLA={Sun:[4,0,20],Moon:[1,4,30],Mars:[0,0,12],Mercury:[5,16,20],Jupiter:[8,0,10],Venus:[6,0,15],Saturn:[10,0,20]};
const FRIENDS={Sun:{f:['Moon','Mars','Jupiter'],e:['Venus','Saturn']},Moon:{f:['Sun','Mercury'],e:[]},Mars:{f:['Sun','Moon','Jupiter'],e:['Mercury']},
  Mercury:{f:['Sun','Venus'],e:['Moon']},Jupiter:{f:['Sun','Moon','Mars'],e:['Mercury','Venus']},Venus:{f:['Mercury','Saturn'],e:['Sun','Moon']},Saturn:{f:['Mercury','Venus'],e:['Sun','Moon','Mars']}};
const relOf=(a,b)=>{const t=FRIENDS[a];return !t?'neutral':t.f.includes(b)?'friend':t.e.includes(b)?'enemy':'neutral'};
function dignity(name,lon){
  if(name==='Rahu'||name==='Ketu')return 'no classical consensus';
  const s=Math.floor(lon/30),d=lon%30,ex=EXALT[name];
  if(ex[0]===s)return 'exalted';
  if((ex[0]+6)%12===s)return 'debilitated';
  const m=MOOLA[name];
  if(m[0]===s&&d>=m[1]&&d<m[2])return 'moolatrikona';
  if(OWN[name].includes(s))return 'own sign';
  const l=SIGN_LORD[s];const r=relOf(name,l);
  return r==='friend'?"friend's sign":r==='enemy'?"enemy's sign":"neutral sign";
}
const COMBUST={Moon:12,Mars:17,Mercury:14,Jupiter:11,Venus:10,Saturn:15};
function angSep(a,b){return Math.abs(sdiff(a,b))}

/* ---------- chart ---------- */
function computeChart(p){ // p:{utcMs,lat,lon,nodeMode}
  const {pos,ayan}=siderealPositions(p.utcMs,p.nodeMode||'mean');
  const asc=norm(ascendantTropical(p.utcMs,p.lat,p.lon)-ayan);
  const lagna=Math.floor(asc/30);
  const planets={};
  for(const n of GRAHAS){
    const q=pos[n],lon=q.lon,sign=Math.floor(lon/30);
    const nakSize=360/27,ni=Math.floor(lon/nakSize);
    const o={name:n,lon,speed:q.speed,retro:q.retro,sign,deg:lon%30,house:(sign-lagna+12)%12+1,
      nak:ni,pada:Math.floor((lon%nakSize)/(nakSize/4))+1,dignity:dignity(n,lon)};
    if(COMBUST[n]){
      const lim=(n==='Mercury'&&q.retro)?12:(n==='Venus'&&q.retro)?8:COMBUST[n];
      o.sunSep=angSep(lon,pos.Sun.lon);o.combust=o.sunSep<lim;
    }
    planets[n]=o;
  }
  const outer={};
  for(const n of ['Uranus','Neptune','Pluto']){
    try{const lon=norm(eclLonJ2000(n,p.utcMs)-AYAN2000),sign=Math.floor(lon/30);outer[n]={lon,sign,deg:lon%30,house:(sign-lagna+12)%12+1}}catch(e){}
  }
  const ch={input:p,ayan,asc,lagna,planets,outer};
  ch.lagnaInfo={lon:asc,sign:lagna,deg:asc%30,nak:Math.floor(asc/(360/27)),pada:Math.floor((asc%(360/27))/(360/108))+1};
  return ch;
}
const lordOfHouse=(ch,h)=>SIGN_LORD[(ch.lagna+h-1)%12];
const housesRuled=(ch,pl)=>{const r=[];for(let h=1;h<=12;h++)if(lordOfHouse(ch,h)===pl)r.push(h);return r};
const occupants=(ch,h)=>GRAHAS.filter(g=>ch.planets[g].house===h);

/* ---------- aspects (Parashari graha drishti, whole sign) ---------- */
const ASPECT_N={Sun:[7],Moon:[7],Mercury:[7],Venus:[7],Mars:[4,7,8],Jupiter:[5,7,9],Saturn:[3,7,10],Rahu:[7],Ketu:[7]};
function aspectsCast(ch,pl){const s=ch.planets[pl].sign;return ASPECT_N[pl].map(n=>({n,sign:(s+n-1)%12,house:((s+n-1)%12-ch.lagna+12)%12+1}))}
function aspectedBy(ch,pl){
  const s=ch.planets[pl].sign;
  return GRAHAS.filter(g=>g!==pl).filter(g=>ASPECT_N[g].some(n=>(ch.planets[g].sign+n-1)%12===s));
}
const conjunctWith=(ch,pl)=>GRAHAS.filter(g=>g!==pl&&ch.planets[g].sign===ch.planets[pl].sign);

/* ---------- divisional charts (Parashari) ---------- */
const VARGAS=[
 ['D1','Rashi','Whole life, body'],['D2','Hora','Wealth'],['D3','Drekkana','Siblings, courage'],['D4','Chaturthamsha','Property, fortune'],['D6','Shashthamsha','Health and disease (not one of the 16 classical vargas; JHora-style rule)'],
 ['D7','Saptamsha','Children'],['D9','Navamsha','Spouse, dharma, strength of planets'],['D10','Dashamsha','Profession'],['D12','Dwadashamsha','Parents'],
 ['D16','Shodashamsha','Vehicles, comforts'],['D20','Vimshamsha','Spiritual practice'],['D24','Siddhamsha','Learning, education'],['D27','Bhamsha','Strengths and weaknesses'],
 ['D30','Trimshamsha','Misfortunes'],['D40','Khavedamsha','Maternal lineage effects'],['D45','Akshavedamsha','Paternal lineage effects'],['D60','Shashtiamsha','Past-life karma, fine detail'],['CH','Chandra Lagna','Mind and emotions (Moon taken as Lagna)']];
const kind=s=>[0,1,2][s%3];        // 0 movable,1 fixed,2 dual
const elem=s=>s%4;                  // 0 fire,1 earth,2 air,3 water
function varga(code,lon){
  const s=Math.floor(lon/30),d=lon%30,odd=s%2===0;let r;
  const P=(n,start)=>(start+Math.min(n-1,Math.floor(d/(30/n))))%12;
  switch(code){
    case 'D1':case 'CH':return s;
    case 'D6':return ((odd?0:6)+Math.min(5,Math.floor(d/5)))%12;
    case 'D2':return (odd?d<15:d>=15)?4:3;
    case 'D3':return (s+4*Math.floor(d/10))%12;
    case 'D4':return (s+3*Math.floor(d/7.5))%12;
    case 'D7':return P(7,odd?s:s+6);
    case 'D9':return P(9,[0,9,6,3][elem(s)]);
    case 'D10':return P(10,odd?s:s+8);
    case 'D12':return P(12,s);
    case 'D16':return P(16,[0,4,8][kind(s)]);
    case 'D20':return P(20,[0,8,4][kind(s)]);
    case 'D24':return P(24,odd?4:3);
    case 'D27':return P(27,[0,3,6,9][elem(s)]);
    case 'D30':{
      const t=odd?[[5,0],[10,10],[18,8],[25,2],[30,6]]:[[5,1],[12,5],[20,11],[25,9],[30,7]];
      for(const [lim,sg] of t)if(d<lim)return sg;return t[4][1];}
    case 'D40':return P(40,odd?0:6);
    case 'D45':return P(45,[0,4,8][kind(s)]);
    case 'D60':return (s+Math.min(59,Math.floor(d*2)))%12;
  }
}
function vargaChart(ch,code){
  const lg=code==='CH'?ch.planets.Moon.sign:varga(code,ch.asc),pl={};
  for(const g of GRAHAS){const sg=varga(code,ch.planets[g].lon);pl[g]={sign:sg,house:(sg-lg+12)%12+1}}
  return {code,lagna:lg,planets:pl};
}

/* ---------- panchang ---------- */
const TITHI=['Pratipada','Dwitiya','Tritiya','Chaturthi','Panchami','Shashthi','Saptami','Ashtami','Navami','Dashami','Ekadashi','Dwadashi','Trayodashi','Chaturdashi'];
const YOGA=['Vishkambha','Priti','Ayushman','Saubhagya','Shobhana','Atiganda','Sukarma','Dhriti','Shula','Ganda','Vriddhi','Dhruva','Vyaghata','Harshana','Vajra','Siddhi','Vyatipata','Variyana','Parigha','Shiva','Siddha','Sadhya','Shubha','Shukla','Brahma','Indra','Vaidhriti'];
const KARANA_R=['Bava','Balava','Kaulava','Taitila','Gara','Vanija','Vishti'];
const VARA=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
function panchang(ch,weekday){
  const s=ch.planets.Sun.lon,m=ch.planets.Moon.lon,el=norm(m-s);
  const ti=Math.floor(el/12),paksha=ti<15?'Shukla':'Krishna';
  const tn=ti===29?'Amavasya':ti===14?'Purnima':TITHI[ti%15];
  const k=Math.floor(el/6);
  const kn=k===0?'Kimstughna':k>=57?['Shakuni','Chatushpada','Naga'][k-57]:KARANA_R[(k-1)%7];
  return {tithi:`${paksha} ${tn}`,tithiNum:ti+1,yoga:YOGA[Math.floor(norm(s+m)/(360/27))],karana:kn,vara:VARA[weekday],elong:el};
}

/* ---------- vimshottari ---------- */
function dashaTree(ch){
  const m=ch.planets.Moon.lon,size=360/27,ni=Math.floor(m/size),frac=(m%size)/size;
  const lord=DASHA_SEQ[ni%9],birth=ch.input.utcMs;
  const startMs=birth-DASHA_YRS[lord]*frac*YEAR_DAYS*86400000;
  const list=[];let t=startMs,i=DASHA_SEQ.indexOf(lord);
  for(let k=0;k<9;k++){
    const L=DASHA_SEQ[(i+k)%9],len=DASHA_YRS[L]*YEAR_DAYS*86400000;
    list.push({lord:L,start:t,end:t+len,years:DASHA_YRS[L]});t+=len;
  }
  return {moonNak:ni,balanceYears:DASHA_YRS[lord]*(1-frac),list};
}
function subPeriods(parent){ // antardasha of a maha, or pratyantar of an antar
  const len=parent.end-parent.start,i=DASHA_SEQ.indexOf(parent.lord),out=[];let t=parent.start;
  for(let k=0;k<9;k++){const L=DASHA_SEQ[(i+k)%9],d=len*DASHA_YRS[L]/120;out.push({lord:L,start:t,end:t+d});t+=d}
  return out;
}

/* ---------- ashtakavarga (BPHS) ---------- */
const AV={
 Sun:{Sun:[1,2,4,7,8,9,10,11],Moon:[3,6,10,11],Mars:[1,2,4,7,8,9,10,11],Mercury:[3,5,6,9,10,11,12],Jupiter:[5,6,9,11],Venus:[6,7,12],Saturn:[1,2,4,7,8,9,10,11],Lagna:[3,4,6,10,11,12]},
 Moon:{Sun:[3,6,7,8,10,11],Moon:[1,3,6,7,10,11],Mars:[2,3,5,6,9,10,11],Mercury:[1,3,4,5,7,8,10,11],Jupiter:[1,4,7,8,10,11,12],Venus:[3,4,5,7,9,10,11],Saturn:[3,5,6,11],Lagna:[3,6,10,11]},
 Mars:{Sun:[3,5,6,10,11],Moon:[3,6,11],Mars:[1,2,4,7,8,10,11],Mercury:[3,5,6,11],Jupiter:[6,10,11,12],Venus:[6,8,11,12],Saturn:[1,4,7,8,9,10,11],Lagna:[1,3,6,10,11]},
 Mercury:{Sun:[5,6,9,11,12],Moon:[2,4,6,8,10,11],Mars:[1,2,4,7,8,9,10,11],Mercury:[1,3,5,6,9,10,11,12],Jupiter:[6,8,11,12],Venus:[1,2,3,4,5,8,9,11],Saturn:[1,2,4,7,8,9,10,11],Lagna:[1,2,4,6,8,10,11]},
 Jupiter:{Sun:[1,2,3,4,7,8,9,10,11],Moon:[2,5,7,9,11],Mars:[1,2,4,7,8,10,11],Mercury:[1,2,4,5,6,9,10,11],Jupiter:[1,2,3,4,7,8,10,11],Venus:[2,5,6,9,10,11],Saturn:[3,5,6,12],Lagna:[1,2,4,5,6,7,9,10,11]},
 Venus:{Sun:[8,11,12],Moon:[1,2,3,4,5,8,9,11,12],Mars:[3,5,6,9,11,12],Mercury:[3,5,6,9,11],Jupiter:[5,8,9,10,11],Venus:[1,2,3,4,5,8,9,10,11],Saturn:[3,4,5,8,9,10,11],Lagna:[1,2,3,4,5,8,9,11]},
 Saturn:{Sun:[1,2,4,7,8,10,11],Moon:[3,6,11],Mars:[3,5,6,10,11,12],Mercury:[6,8,9,10,11,12],Jupiter:[5,6,11,12],Venus:[6,11,12],Saturn:[3,5,6,11],Lagna:[1,3,4,6,10,11]}};
const AV_TOTAL={Sun:48,Moon:49,Mars:39,Mercury:54,Jupiter:56,Venus:52,Saturn:39};
function ashtakavarga(ch){
  const src={};for(const g of SEVEN)src[g]=ch.planets[g].sign;src.Lagna=ch.lagna;
  const bav={},sarva=Array(12).fill(0);
  for(const P of SEVEN){
    const row=Array(12).fill(0);
    for(let s=0;s<12;s++)for(const c of Object.keys(AV[P])){
      if(AV[P][c].includes((s-src[c]+12)%12+1))row[s]++;
    }
    bav[P]=row;row.forEach((v,i)=>sarva[i]+=v);
  }
  const ok=SEVEN.every(P=>bav[P].reduce((a,b)=>a+b,0)===AV_TOTAL[P]);
  return {bav,sarva,ok};
}

/* ---------- yogas & doshas ---------- */
const KENDRA=[1,4,7,10],TRIKONA=[1,5,9],DUSTH=[6,8,12];
const fromH=(a,b)=>(b-a+12)%12+1; // house number of b counted from a
function yogas(ch){
  const P=ch.planets,found=[],notFound=[];
  const add=(name,src,detail)=>found.push({name,src,detail});
  const chk=(cond,name,src,detail)=>cond?add(name,src,detail):notFound.push(name);
  const sg=n=>P[n].sign,hs=n=>P[n].house;
  const hsn=n=>`${SIGNS[sg(n)]}, house ${hs(n)}`;
  // Pancha Mahapurusha (BPHS ch.75)
  const pm={Mars:'Ruchaka',Mercury:'Bhadra',Jupiter:'Hamsa',Venus:'Malavya',Saturn:'Sasa'};
  for(const [g,y] of Object.entries(pm)){
    const dg=P[g].dignity;
    chk((dg==='own sign'||dg==='exalted'||dg==='moolatrikona')&&KENDRA.includes(hs(g)),`${y} Yoga`,'BPHS ch.75',`${g} is ${dg} in ${hsn(g)} (kendra from Lagna).`);
  }
  // Gajakesari
  chk(KENDRA.includes(fromH(P.Moon.house,P.Jupiter.house)),'Gajakesari Yoga','Phaladeepika / BPHS',`Jupiter is house ${fromH(P.Moon.house,P.Jupiter.house)} from the Moon (kendra).`);
  // Budhaditya
  chk(sg('Sun')===sg('Mercury'),'Budhaditya Yoga','Phaladeepika',`Sun and Mercury together in ${SIGNS[sg('Sun')]} (${P.Mercury.sunSep.toFixed(1)}° apart)${P.Mercury.combust?'; Mercury is combust by the standard orb':''}.`);
  chk(sg('Moon')===sg('Mars'),'Chandra-Mangala Yoga','Traditional',`Moon and Mars together in ${SIGNS[sg('Moon')]}.`);
  // Sunapha / Anapha / Duradhara / Kemadruma (from Moon, excluding Sun & nodes)
  const cand=['Mars','Mercury','Jupiter','Venus','Saturn'];
  const in2=cand.filter(g=>fromH(P.Moon.house,hs(g))===2),in12=cand.filter(g=>fromH(P.Moon.house,hs(g))===12),withM=cand.filter(g=>sg(g)===sg('Moon'));
  if(in2.length&&in12.length)add('Duradhara Yoga','BPHS ch.35',`Planets on both sides of the Moon: ${in12.join(', ')} (12th) and ${in2.join(', ')} (2nd).`);
  else if(in2.length)add('Sunapha Yoga','BPHS ch.35',`${in2.join(', ')} in the 2nd from the Moon.`);
  else if(in12.length)add('Anapha Yoga','BPHS ch.35',`${in12.join(', ')} in the 12th from the Moon.`);
  else if(!withM.length){
    const canc=KENDRA.includes(P.Moon.house)||cand.some(g=>KENDRA.includes(fromH(P.Moon.house,hs(g))));
    add('Kemadruma Yoga','BPHS ch.35',`No planet (excluding Sun and nodes) in the 2nd, 12th or with the Moon.${canc?' A cancellation condition is present (Moon in kendra from Lagna, or a planet in kendra from the Moon); judge strength separately.':''}`);
  }else notFound.push('Sunapha / Anapha / Duradhara / Kemadruma');
  // Vesi / Vosi / Ubhayachari (from Sun, excluding Moon & nodes)
  const c2=['Mars','Mercury','Jupiter','Venus','Saturn'];
  const s2=c2.filter(g=>fromH(P.Sun.house,hs(g))===2),s12=c2.filter(g=>fromH(P.Sun.house,hs(g))===12);
  if(s2.length&&s12.length)add('Ubhayachari Yoga','BPHS ch.35',`${s12.join(', ')} (12th) and ${s2.join(', ')} (2nd) from the Sun.`);
  else if(s2.length)add('Vesi Yoga','BPHS ch.35',`${s2.join(', ')} in the 2nd from the Sun.`);
  else if(s12.length)add('Vosi Yoga','BPHS ch.35',`${s12.join(', ')} in the 12th from the Sun.`);
  else notFound.push('Vesi / Vosi / Ubhayachari');
  // Yogakaraka + Raja yoga: kendra lords (1,4,7,10) with trikona lords (1,5,9) by conjunction, exchange or mutual aspect (BPHS ch.36)
  for(const g of SEVEN){const r=housesRuled(ch,g);if(r.some(h=>[4,7,10].includes(h))&&r.some(h=>[5,9].includes(h)))add('Yogakaraka','BPHS ch.34',`${g} rules houses ${r.join(' & ')} (kendra + trikona) for ${SIGNS[ch.lagna]} Lagna; placed in ${hsn(g)}.`)}
  const mutual=(a,b)=>ASPECT_N[a].some(n=>(sg(a)+n-1)%12===sg(b))&&ASPECT_N[b].some(n=>(sg(b)+n-1)%12===sg(a));
  const done=new Set();let rj=0;
  for(const kh of [1,4,7,10])for(const th of [1,5,9]){
    if(kh===th)continue;
    const k=lordOfHouse(ch,kh),t=lordOfHouse(ch,th);
    if(k===t||done.has([k,t].sort().join()))continue;
    let how=null;
    if(sg(k)===sg(t))how=`together in ${SIGNS[sg(k)]}`;
    else if(SIGN_LORD[sg(k)]===t&&SIGN_LORD[sg(t)]===k)how='in sign exchange (parivartana)';
    else if(mutual(k,t))how='in mutual aspect';
    if(how){done.add([k,t].sort().join());rj++;add('Raja Yoga','BPHS ch.36',`Lord of ${kh} (${k}) and lord of ${th} (${t}) are ${how}.`)}
  }
  if(!rj)notFound.push('Raja Yoga by kendra–trikona lords (conjunction, exchange, mutual aspect)');
  // Viparita Raja Yoga
  const vr={6:'Harsha',8:'Sarala',12:'Vimala'};
  for(const h of DUSTH){const L=lordOfHouse(ch,h);
    chk(DUSTH.includes(hs(L)),`${vr[h]} (Viparita Raja) Yoga`,'BPHS ch.36',`Lord of ${h} (${L}) is placed in house ${hs(L)} (dusthana).`)}
  // Parivartana between any two planets
  const seen=new Set();
  for(const a of SEVEN)for(const b of SEVEN){
    if(a>=b)continue;
    if(SIGN_LORD[sg(a)]===b&&SIGN_LORD[sg(b)]===a&&sg(a)!==sg(b)&&!seen.has(a+b)){seen.add(a+b);
      add('Parivartana Yoga','BPHS ch.36',`${a} in ${SIGNS[sg(a)]} and ${b} in ${SIGNS[sg(b)]} exchange signs (houses ${hs(a)} & ${hs(b)}).`)}
  }
  // Neecha Bhanga
  for(const g of SEVEN)if(P[g].dignity==='debilitated'){
    const d=SIGN_LORD[sg(g)],e=SIGN_LORD[EXALT[g][0]];const ref=n=>KENDRA.includes(hs(n))||KENDRA.includes(fromH(P.Moon.house,hs(n)));
    const c=[];if(ref(d))c.push(`dispositor ${d} is in a kendra from Lagna/Moon`);if(ref(e))c.push(`lord of ${g}'s exaltation sign (${e}) is in a kendra from Lagna/Moon`);
    add(c.length?'Neecha Bhanga (cancellation condition present)':'Debilitated planet, no standard cancellation found','BPHS ch.28 / Phaladeepika',`${g} is debilitated in ${hsn(g)}${c.length?': '+c.join('; ')+'.':'. Other cancellation rules are not evaluated.'}`);
  }
  // Kaal Sarpa (modern; not in BPHS)
  const r=P.Rahu.lon,inArc=g=>norm(P[g].lon-r)<180;
  const all1=SEVEN.every(inArc),all2=SEVEN.every(g=>!inArc(g));
  chk(all1||all2,'Kala Sarpa (modern doctrine)','Later tradition, not in BPHS',`All seven planets lie on one side of the Rahu–Ketu axis (${all1?'Rahu→Ketu':'Ketu→Rahu'}).`);
  // Mangal dosha
  const md=[];
  for(const [ref,lab] of [[ch.lagna,'Lagna'],[P.Moon.sign,'Moon'],[P.Venus.sign,'Venus']]){
    const h=(P.Mars.sign-ref+12)%12+1;
    if([1,2,4,7,8,12].includes(h))md.push(`house ${h} from ${lab}`);
  }
  const doshas=[];
  if(md.length)doshas.push({name:'Mangal (Kuja) Dosha',src:'Traditional (Muhurta/Jataka texts)',detail:`Mars is in ${md.join('; ')}. Inclusion of the 2nd house and cancellations differ between authorities and are not evaluated here.`});
  else doshas.push({name:'Mangal (Kuja) Dosha — not indicated',src:'Traditional',detail:'Mars is not in houses 1, 2, 4, 7, 8, 12 from Lagna, Moon or Venus.'});
  return {found,notFound,doshas};
}
const NOT_IMPLEMENTED=['Shadbala (six-fold strength)','Ashtakavarga prastara / shodhana / kakshya','Bhava Chalit (Sripati) cusps','Jaimini karakas and Chara Dasha','Yogini and other non-Vimshottari dasha systems','Muhurta and Panchaka','Remedies (upaya)'];

/* ---------- transit ---------- */
function transitNow(ch,ms,nodeMode){
  const {pos}=siderealPositions(ms,nodeMode||'mean');const o={};
  for(const g of GRAHAS){const lon=pos[g].lon,s=Math.floor(lon/30);
    o[g]={lon,sign:s,deg:lon%30,retro:pos[g].retro,fromLagna:(s-ch.lagna+12)%12+1,fromMoon:(s-ch.planets.Moon.sign+12)%12+1,nak:Math.floor(lon/(360/27))}}
  const sat=o.Saturn.fromMoon;
  o.sadeSati=sat===12?'Sade Sati — first phase (Saturn in 12th from natal Moon)':sat===1?'Sade Sati — peak phase (Saturn over natal Moon sign)':sat===2?'Sade Sati — last phase (Saturn in 2nd from natal Moon)':
    (sat===4?'Kantaka/Ardhashtama Shani (Saturn in 4th from Moon)':sat===8?'Ashtama Shani (Saturn in 8th from Moon)':'No Sade Sati');
  return o;
}

/* ---------- Ashta-Kuta matching (all 8 kutas, 36 points) ---------- */
const NAK_GANA=(()=>{const a=Array(27).fill('Manushya');[0,4,6,7,12,14,16,21,26].forEach(i=>a[i]='Deva');[2,8,9,13,15,17,18,22,23].forEach(i=>a[i]='Rakshasa');return a})();
const NADI=['Adi','Madhya','Antya','Antya','Madhya','Adi'];
const varnaRank=s=>[3,2,1,4,3,2,1,4,3,2,1,4][s]; // Brahmin 4, Kshatriya 3, Vaishya 2, Shudra 1 (by Moon sign)
const ANIMALS=['Horse','Elephant','Sheep','Serpent','Dog','Cat','Rat','Cow','Buffalo','Tiger','Deer','Monkey','Mongoose','Lion'];
const NAK_ANIMAL=[0,1,2,3,3,4,5,2,5,6,6,7,8,9,8,9,10,10,4,11,12,11,13,0,13,7,1];
const YONI=[[4,2,2,3,2,2,2,1,0,1,3,3,2,1],[2,4,3,3,2,2,2,2,3,1,2,3,2,0],[2,3,4,2,1,2,1,3,3,1,2,0,3,1],[3,3,2,4,2,1,1,1,1,2,2,2,0,2],
 [2,2,1,2,4,2,1,2,2,1,0,2,1,1],[2,2,2,1,2,4,0,2,2,1,3,3,2,1],[2,2,1,1,1,0,4,2,2,2,2,2,1,2],[1,2,3,1,2,2,2,4,3,0,3,2,2,1],
 [0,3,3,1,2,2,2,3,4,1,2,2,2,1],[1,1,1,2,1,1,2,0,1,4,1,1,2,1],[3,2,2,2,0,3,2,3,2,1,4,2,2,1],[3,3,0,2,2,3,2,2,2,1,2,4,3,2],
 [2,2,3,0,1,2,1,2,2,2,2,3,4,2],[1,0,1,2,1,1,2,1,1,1,1,2,2,4]];
const VASHYA_G=['Chatushpada','Manava','Jalachara','Vanachara','Keeta'];
const VASHYA=[[2,1,1,0,1],[1,2,0.5,0,1],[1,0.5,2,1,1],[0,0,1,2,0],[1,1,1,0,2]]; // cross-group values: widely circulated table, symmetric; only same-group (2) verified
function vashyaGroup(sign,deg){
  if(sign<=1)return 0;if([2,5,6,10].includes(sign))return 1;if(sign===3||sign===11)return 2;if(sign===4)return 3;if(sign===7)return 4;
  if(sign===8)return deg<15?1:0;return deg<15?0:2;
}
function maitri(a,b){
  const x=relOf(a,b),y=relOf(b,a);
  if(a===b)return 5;
  return {'friend+friend':5,'friend+neutral':4,'neutral+neutral':3,'enemy+friend':1,'enemy+neutral':0.5,'enemy+enemy':0}[[x,y].sort().join('+')];
}
function matchKutas(bride,groom){ // each: {moonSign, moonDeg, nak}
  const r=[];
  const vB=varnaRank(bride.moonSign),vG=varnaRank(groom.moonSign);
  r.push({name:'Varna',max:1,score:vG>=vB?1:0,note:`Groom ${vG>=vB?'≥':'<'} bride in varna rank`});
  const gv=vashyaGroup(groom.moonSign,groom.moonDeg||0),bv=vashyaGroup(bride.moonSign,bride.moonDeg||0);
  r.push({name:'Vashya',max:2,score:VASHYA[gv][bv],note:`Groom ${VASHYA_G[gv]}, bride ${VASHYA_G[bv]}${gv===bv?'':' (cross-group value not independently verified)'}`});
  const cnt=(a,b)=>((b-a+27)%27)+1;
  const good=n=>![3,5,7].includes(n%9);
  const t1=good(cnt(bride.nak,groom.nak)),t2=good(cnt(groom.nak,bride.nak));
  r.push({name:'Tara',max:3,score:(t1?1.5:0)+(t2?1.5:0),note:`Counts ${cnt(bride.nak,groom.nak)} and ${cnt(groom.nak,bride.nak)}`});
  const yb=NAK_ANIMAL[bride.nak],yg=NAK_ANIMAL[groom.nak];
  r.push({name:'Yoni',max:4,score:YONI[yg][yb],note:`Groom ${ANIMALS[yg]}, bride ${ANIMALS[yb]}${YONI[yg][yb]===0?' (natural enemies)':''}`});
  r.push({name:'Graha Maitri',max:5,score:maitri(SIGN_LORD[bride.moonSign],SIGN_LORD[groom.moonSign]),note:`Moon-sign lords ${SIGN_LORD[bride.moonSign]} / ${SIGN_LORD[groom.moonSign]}`});
  const gB=NAK_GANA[bride.nak],gG=NAK_GANA[groom.nak];
  const gt={'Deva-Deva':6,'Deva-Manushya':6,'Deva-Rakshasa':1,'Manushya-Deva':5,'Manushya-Manushya':6,'Manushya-Rakshasa':0,'Rakshasa-Deva':0,'Rakshasa-Manushya':0,'Rakshasa-Rakshasa':6};
  r.push({name:'Gana',max:6,score:gt[gG+'-'+gB],note:`Groom ${gG}, bride ${gB}`});
  const d=((groom.moonSign-bride.moonSign+12)%12)+1,bad=[2,12,5,9,6,8].includes(d);
  r.push({name:'Bhakoot',max:7,score:bad?0:7,note:`Moon signs are ${d}/${(14-d)%12||12} from each other`});
  const nB=NADI[bride.nak%6],nG=NADI[groom.nak%6];
  r.push({name:'Nadi',max:8,score:nB===nG?0:8,note:`Bride ${nB}, groom ${nG}`});
  return r;
}

/* ---------- dignity by sign only (for divisional charts) ---------- */
function dignitySign(name,sign){
  if(name==='Rahu'||name==='Ketu')return '—';
  if(EXALT[name][0]===sign)return 'exalted';if((EXALT[name][0]+6)%12===sign)return 'debilitated';
  if(OWN[name].includes(sign))return 'own sign';
  const r=relOf(name,SIGN_LORD[sign]);return r==='friend'?"friend's sign":r==='enemy'?"enemy's sign":'neutral sign';
}

/* ---------- bhava (house) report ---------- */
const isBenefic=(ch,g)=>g==='Moon'?norm(ch.planets.Moon.lon-ch.planets.Sun.lon)<180:['Jupiter','Venus','Mercury'].includes(g);
function bhava(ch,h){
  const sign=(ch.lagna+h-1)%12,lord=SIGN_LORD[sign],lp=ch.planets[lord],occ=occupants(ch,h);
  const asp=GRAHAS.filter(g=>ch.planets[g].house!==h&&aspectsCast(ch,g).some(a=>a.house===h));
  const sup=[],cha=[],dg=lp.dignity;
  if(['exalted','own sign','moolatrikona'].includes(dg))sup.push(`lord ${lord} is ${dg}`);
  if(dg==='debilitated')cha.push(`lord ${lord} is debilitated`);
  if(KENDRA.includes(lp.house)||[5,9].includes(lp.house))sup.push(`lord ${lord} is in house ${lp.house} (kendra/trikona)`);
  if(DUSTH.includes(lp.house)&&!DUSTH.includes(h))cha.push(`lord ${lord} is in house ${lp.house} (dusthana)`);
  if(lp.combust)cha.push(`lord ${lord} is combust`);
  for(const g of occ){
    if(isBenefic(ch,g))sup.push(`${g} (benefic) occupies it`);
    else if([3,6,10,11].includes(h))sup.push(`${g} (malefic) occupies an upachaya house, where malefics are said to do well`);
    else cha.push(`${g} (malefic) occupies it`);
  }
  for(const g of asp)(isBenefic(ch,g)?sup:cha).push(`${g} (${isBenefic(ch,g)?'benefic':'malefic'}) aspects it`);
  return {h,sign,lord,occ,asp,sup,cha,dust:DUSTH.includes(h)};
}
const PLANET_WORK={Sun:'government, administration, authority, medicine',Moon:'public dealing, nursing, hospitality, liquids, food',Mars:'surgery, engineering, defence or police, land',
 Mercury:'writing, accounts, commerce, teaching, communication',Jupiter:'teaching, law, counselling, finance, religion',Venus:'arts, design, luxury goods, entertainment, hospitality',
 Saturn:'service, industry, mining, construction, long-term institutions',Rahu:'foreign dealings, technology, unconventional fields',Ketu:'research, spirituality, technical or detached work'};
function dashaWindows(ch,set,fromMs,years){
  const t=dashaTree(ch),end=fromMs+years*YEAR_DAYS*86400000,both=[],anta=[];
  for(const m of t.list){
    if(m.end<fromMs||m.start>end)continue;
    for(const a of subPeriods(m)){
      if(a.end<fromMs||a.start>end)continue;
      const row={m:m.lord,a:a.lord,start:Math.max(a.start,fromMs),end:a.end};
      if(set.includes(m.lord)&&set.includes(a.lord))both.push(row);else if(set.includes(a.lord))anta.push(row);
    }
  }
  return {both,anta};
}

/* ---------- gochara (transit from natal Moon) ---------- */
const GOCHARA_FAV={Sun:[3,6,10,11],Moon:[1,3,6,7,10,11],Mars:[3,6,11],Mercury:[2,4,6,8,10,11],Jupiter:[2,5,7,9,11],Venus:[1,2,3,4,5,8,9,11,12],Saturn:[3,6,11],Rahu:[3,6,10,11],Ketu:[3,6,10,11]};
const GOCHARA_AREAS={Overview:GRAHAS,Romance:['Venus','Moon','Jupiter'],Career:['Sun','Mars','Jupiter','Saturn'],Finance:['Jupiter','Mercury','Venus'],Health:['Sun','Moon','Mars','Saturn']};
const TARA_NAMES=['Janma','Sampat','Vipat','Kshema','Pratyari','Sadhaka','Vadha','Mitra','Ati-mitra'];
function gochara(ch,ms,nodeMode){
  const T=transitNow(ch,ms,nodeMode),fav={};
  for(const g of GRAHAS)fav[g]=GOCHARA_FAV[g].includes(T[g].fromMoon);
  const areas={};
  for(const [k,list] of Object.entries(GOCHARA_AREAS)){
    const n=list.filter(g=>fav[g]).length,ratio=n/list.length;
    areas[k]={n,of:list.length,label:ratio>=0.67?'Favourable':ratio>=0.34?'Mixed':'Challenging'};
  }
  const cnt=((T.Moon.nak-ch.planets.Moon.nak+27)%27)+1,tara=cnt%9||9;
  return {T,fav,areas,tara:TARA_NAMES[tara-1],taraGood:![3,5,7].includes(tara),count:GRAHAS.filter(g=>fav[g]).length};
}

/* ---------- server-side aggregator: precompute everything for one request ---------- */
export function buildFullChart(input){
  const ch = computeChart(input);
  let wd = new Date(Date.UTC(input.y, input.mo-1, input.d)).getUTCDay();
  try{
    const st = Date.UTC(input.y, input.mo-1, input.d) - input.offsetMin*60000;
    const r = Astronomy.SearchRiseSet('Sun', new Astronomy.Observer(input.lat, input.lon, 0), +1, new Date(st), 1);
    if(r){ const sunrise=r.date.getTime(); if(input.utcMs < sunrise) wd=(wd+6)%7; }
  }catch(e){}
  const pan = panchang(ch, wd);

  const vargas={};
  for(const [code] of VARGAS) vargas[code]=vargaChart(ch,code);

  const dt = dashaTree(ch);
  const tree = dt.list.map(m=>({
    lord:m.lord, start:m.start, end:m.end,
    antar: subPeriods(m).map(a=>({
      lord:a.lord, start:a.start, end:a.end,
      pratyantar: subPeriods({lord:a.lord,start:a.start,end:a.end}).map(p=>({lord:p.lord,start:p.start,end:p.end}))
    }))
  }));

  const av = ashtakavarga(ch);
  const yg = yogas(ch);

  const bhavas=[null];
  for(let h=1;h<=12;h++) bhavas.push(bhava(ch,h));

  const planetsOut={};
  for(const g of GRAHAS){
    const p=ch.planets[g];
    planetsOut[g]={...p,
      rules: housesRuled(ch,g),
      aspectsCast: aspectsCast(ch,g),
      aspectedBy: aspectedBy(ch,g),
      conjunct: conjunctWith(ch,g)
    };
  }

  return {
    ayan: ch.ayan, asc: ch.asc, lagna: ch.lagna, lagnaInfo: ch.lagnaInfo,
    planets: planetsOut, outer: ch.outer,
    panchang: pan, vargas, dashaTree: {moonNak: dt.moonNak, balanceYears: dt.balanceYears, list: tree},
    ashtakavarga: av, yogas: yg, bhavas
  };
}

export function transitFor(lagna, moonSign, ms, nodeMode){
  const fakeCh = {lagna, planets:{Moon:{sign:moonSign}}};
  return gochara(fakeCh, ms, nodeMode||'mean');
}

export { matchKutas, tzOffsetMin };
