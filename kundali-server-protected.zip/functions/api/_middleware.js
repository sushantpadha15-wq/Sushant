// A basic, best-effort limiter. Cloudflare Workers can spin up fresh instances,
// so this in-memory map is NOT a strong guarantee on its own — set up a proper
// Rate Limiting rule in the Cloudflare dashboard (Security > WAF > Rate limiting
// rules) for real protection against scripted abuse. This just catches the
// obvious case of one instance being hammered.
const hits = new Map();
const WINDOW_MS = 60000, MAX_PER_WINDOW = 30;

export async function onRequest(context){
  const ip = context.request.headers.get('CF-Connecting-IP') || 'unknown';
  const now = Date.now();
  const rec = hits.get(ip);
  if(!rec || now - rec.start > WINDOW_MS){
    hits.set(ip, {start: now, count: 1});
  }else{
    rec.count++;
    if(rec.count > MAX_PER_WINDOW){
      return new Response(JSON.stringify({error:'Too many requests. Please wait a minute and try again.'}), {
        status: 429, headers: {'content-type':'application/json','retry-after':'60'}
      });
    }
  }
  if(hits.size > 5000) hits.clear(); // crude memory guard
  return context.next();
}
