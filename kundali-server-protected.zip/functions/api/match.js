import { matchKutas } from '../_lib/engine.js';

function validPerson(p){
  return p && typeof p.moonSign==='number' && p.moonSign>=0 && p.moonSign<12
    && typeof p.moonDeg==='number' && typeof p.nak==='number' && p.nak>=0 && p.nak<27;
}

export async function onRequestPost(context){
  let body;
  try{ body = await context.request.json(); }catch(e){ return new Response(JSON.stringify({error:'Invalid JSON'}),{status:400}); }
  const { bride, groom } = body;
  if(!validPerson(bride) || !validPerson(groom))
    return new Response(JSON.stringify({error:'bride and groom each need moonSign (0-11), moonDeg, nak (0-26).'}),{status:400});
  try{
    const result = matchKutas(bride, groom);
    return new Response(JSON.stringify({result}), {headers:{'content-type':'application/json','cache-control':'no-store'}});
  }catch(e){
    return new Response(JSON.stringify({error:'Calculation failed: '+e.message}),{status:500});
  }
}
