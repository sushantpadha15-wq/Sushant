// functions/api/chart.js — runs on Cloudflare's server, never sent to the browser.
import { buildFullChart, tzOffsetMin } from '../_lib/engine.js';

function bad(msg, code=400){
  return new Response(JSON.stringify({error:msg}), {status:code, headers:{'content-type':'application/json'}});
}

export async function onRequestPost(context){
  const { request } = context;
  let body;
  try{ body = await request.json(); }catch(e){ return bad('Invalid JSON body.'); }

  const { dateStr, timeStr, lat, lon, tz, manual, offHours } = body;
  if(!dateStr || !timeStr) return bad('dateStr and timeStr are required.');
  if(typeof lat!=='number' || typeof lon!=='number' || lat<-90 || lat>90 || lon<-180 || lon>180)
    return bad('lat and lon must be numbers in valid ranges.');

  const [y,mo,d] = dateStr.split('-').map(Number);
  const [h,mi,se] = timeStr.split(':').map(Number);
  if(!y||!mo||!d||isNaN(h)||isNaN(mi)) return bad('dateStr must be YYYY-MM-DD and timeStr HH:MM[:SS].');

  let offsetMin;
  if(manual){
    if(typeof offHours!=='number' || isNaN(offHours)) return bad('offHours must be a number when manual is true.');
    offsetMin = Math.round(offHours*60);
  }else{
    if(!tz) return bad('tz (IANA time zone) is required unless manual is true.');
    try{ offsetMin = tzOffsetMin(tz,y,mo,d,h,mi); }catch(e){ return bad('Unrecognised time zone.'); }
  }
  const utcMs = Date.UTC(y,mo-1,d,h,mi,se||0) - offsetMin*60000;
  const nodeMode = body.nodeMode==='true' ? 'true' : 'mean';

  try{
    const chart = buildFullChart({ utcMs, lat, lon, nodeMode, y, mo, d, offsetMin });
    return new Response(JSON.stringify({ chart, offsetMin }), { headers:{'content-type':'application/json','cache-control':'no-store'} });
  }catch(e){
    return bad('Calculation failed: '+e.message, 500);
  }
}

export async function onRequestGet(){
  return new Response('POST birth details as JSON to compute a chart.', {status:405});
}
