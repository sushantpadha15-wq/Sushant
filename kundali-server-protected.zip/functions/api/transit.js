import { transitFor } from '../_lib/engine.js';

export async function onRequestPost(context){
  let body;
  try{ body = await context.request.json(); }catch(e){ return new Response(JSON.stringify({error:'Invalid JSON'}),{status:400}); }
  const { lagna, moonSign, ms, nodeMode } = body;
  if(typeof lagna!=='number' || typeof moonSign!=='number' || typeof ms!=='number')
    return new Response(JSON.stringify({error:'lagna, moonSign and ms (epoch ms) are required numbers.'}),{status:400});
  try{
    const result = transitFor(lagna, moonSign, ms, nodeMode==='true'?'true':'mean');
    return new Response(JSON.stringify({result}), {headers:{'content-type':'application/json','cache-control':'no-store'}});
  }catch(e){
    return new Response(JSON.stringify({error:'Calculation failed: '+e.message}),{status:500});
  }
}
